from pathlib import Path
import json, joblib
import numpy as np
import pandas as pd
from nexora_datahub.loader import load_bars
from nexora_vision.features import build_features
from nexora_intelligence.model import create_model
from nexora_evaluator.metrics import metrics
from nexora_core.config import ROOT,load_config

def prepare(path,horizon,symbol,global_mode=False):
    df=load_bars(path); X=build_features(df)
    if global_mode:
        # Explicit symbol identity for pooled model. Features remain ATR/return normalized.
        X["symbol_code"]=pd.Categorical([symbol]*len(X)).codes.astype(float)
    close=df.close.to_numpy(); fwd=np.full(len(df),np.nan)
    fwd[:-horizon]=close[horizon:]/close[:-horizon]-1
    y=(fwd>0).astype(int)
    mask=X.notna().all(axis=1).to_numpy() & np.isfinite(fwd)
    return df,X,y,fwd,mask

def split_indices(mask,horizon,train_frac=.6,valid_frac=.2,embargo=None):
    if embargo is None: embargo=horizon
    idx=np.flatnonzero(mask); n=len(idx)
    a=int(n*train_frac); b=int(n*valid_frac)
    tr=idx[:a]; va=idx[a+embargo:a+b]; te=idx[a+b+embargo:]
    if min(len(tr),len(va),len(te))<100: raise ValueError("Insufficient rows after split/embargo")
    return tr,va,te

def walk_forward_scores(X,y,mask,horizon,engine,seed,max_iter,folds=3):
    idx=np.flatnonzero(mask); n=len(idx); results=[]
    # Expanding-window folds; all splits chronological and purged by horizon.
    initial=max(int(n*.50),1000)
    remaining=n-initial
    if remaining < folds*100: return results
    chunk=remaining//folds
    for k in range(folds):
        train_end=initial+k*chunk
        test_start=min(train_end+horizon,n)
        test_end=n if k==folds-1 else min(test_start+chunk,n)
        tr=idx[:train_end]; te=idx[test_start:test_end]
        if len(te)<100 or len(np.unique(y[tr]))<2: continue
        model,eng=create_model(engine,seed,max_iter); model.fit(X.iloc[tr],y[tr])
        p=model.predict_proba(X.iloc[te])[:,1]
        m=metrics(y[te],p); m["fold"]=k+1; m["engine"]=eng
        results.append(m)
    return results

def train_one(path,symbol,tf,horizon,kind="individual",engine="auto",max_iter=300,seed=42,margin=.03):
    df,X,y,fwd,mask=prepare(path,horizon,symbol,global_mode=(kind=="global"))
    cfg=load_config()["training"]
    tr,va,te=split_indices(mask,horizon,cfg["train_fraction"],cfg["validation_fraction"],max(horizon,cfg["embargo_bars"]))
    if len(np.unique(y[tr]))<2 or len(np.unique(y[va]))<2: raise ValueError("Train/validation hanya satu kelas")
    model,actual_engine=create_model(engine,seed,max_iter)
    model.fit(X.iloc[tr],y[tr])
    pv=model.predict_proba(X.iloc[va])[:,1]; pt=model.predict_proba(X.iloc[te])[:,1]
    vm=metrics(y[va],pv); tm=metrics(y[te],pt)
    wf=walk_forward_scores(X,y,mask,horizon,engine,seed,max_iter,folds=cfg.get("walk_forward_folds",3))
    base=Path("models")/("individual" if kind=="individual" else "global")/symbol/tf/f"h{horizon}"
    if kind=="global": base=Path("models")/"global"/tf/f"h{horizon}"
    model_dir=ROOT/base; model_dir.mkdir(parents=True,exist_ok=True)
    joblib.dump({"model":model,"features":list(X.columns),"symbol":symbol,"timeframe":tf,
      "horizon":horizon,"engine":actual_engine,"kind":kind},model_dir/"model.joblib")
    sigdir=ROOT/"signals"/symbol/tf/f"h{horizon}"; sigdir.mkdir(parents=True,exist_ok=True)
    direction=np.where(pt>=.5+margin,1,np.where(pt<=.5-margin,-1,0))
    pd.DataFrame({"time":df.ts.iloc[te].dt.strftime("%Y.%m.%d %H:%M").values,
      "prob_up":pt,"direction":direction,"realized_forward_return":fwd[te]}).to_csv(sigdir/f"{kind}_signals.csv",index=False)
    report={"kind":kind,"symbol":symbol,"timeframe":tf,"horizon_bars":horizon,"engine":actual_engine,
      "rows":len(df),"train_rows":len(tr),"validation_rows":len(va),"test_rows":len(te),
      "train_start":str(df.ts.iloc[tr[0]]),"test_start":str(df.ts.iloc[te[0]]),
      "validation_metrics":vm,"test_metrics":tm,"walk_forward":wf,
      "warning":"Directional ML evaluation, not a cost-aware execution backtest."}
    repdir=ROOT/"reports"/kind/symbol/tf/f"h{horizon}"; repdir.mkdir(parents=True,exist_ok=True)
    (repdir/"report.json").write_text(json.dumps(report,indent=2),encoding="utf-8")
    return report
